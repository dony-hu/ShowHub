import{j as e}from"./index-CVcYh08c.js";import{r as d,u as r}from"./router-CFpZ8yAI.js";const o=({onNavigate:t})=>e.jsx("div",{className:"hero-section improvement-hero",children:e.jsxs("div",{className:"hero-content",children:[e.jsx("h1",{children:"反馈与建议"}),e.jsx("p",{className:"hero-subtitle",children:"我们重视您的反馈，请告诉我们如何使产品更好"}),e.jsxs("div",{className:"improvement-buttons",children:[e.jsxs("button",{className:"improvement-button map-corrections",onClick:()=>t("map-corrections"),children:[e.jsx("div",{className:"button-icon",children:"🗺️"}),e.jsxs("div",{className:"button-content",children:[e.jsx("h3",{children:"地图纠错"}),e.jsx("p",{children:"报告地图数据问题"})]})]}),e.jsxs("button",{className:"improvement-button bug-reports",onClick:()=>t("bugs"),children:[e.jsx("div",{className:"button-icon",children:"🐛"}),e.jsxs("div",{className:"button-content",children:[e.jsx("h3",{children:"产品缺陷"}),e.jsx("p",{children:"报告功能或界面问题"})]})]}),e.jsxs("button",{className:"improvement-button feature-requests",onClick:()=>t("features"),children:[e.jsx("div",{className:"button-icon",children:"✨"}),e.jsxs("div",{className:"button-content",children:[e.jsx("h3",{children:"功能改进"}),e.jsx("p",{children:"建议新功能或改进"})]})]})]}),e.jsxs("div",{className:"feedback-info",children:[e.jsx("h2",{children:"其他反馈方式"}),e.jsxs("div",{className:"contact-methods",children:[e.jsxs("div",{className:"contact-item",children:[e.jsx("div",{className:"contact-icon",children:"📧"}),e.jsxs("div",{className:"contact-details",children:[e.jsx("h4",{children:"邮件联系"}),e.jsxs("p",{children:["发送邮件至：",e.jsx("a",{href:"mailto:feedback@fengtukj.com",children:"feedback@fengtukj.com"})]}),e.jsx("p",{className:"contact-note",children:"我们将在 1-2 个工作日内回复"})]})]}),e.jsxs("div",{className:"contact-item",children:[e.jsx("div",{className:"contact-icon",children:"💬"}),e.jsxs("div",{className:"contact-details",children:[e.jsx("h4",{children:"在线客服"}),e.jsx("p",{children:"工作日 9:00-18:00 在线服务"}),e.jsx("button",{className:"contact-button",children:"联系客服"})]})]}),e.jsxs("div",{className:"contact-item",children:[e.jsx("div",{className:"contact-icon",children:"📱"}),e.jsxs("div",{className:"contact-details",children:[e.jsx("h4",{children:"微信公众号"}),e.jsx("p",{children:'关注"丰图科技"获取最新动态'}),e.jsx("p",{className:"contact-note",children:"扫码关注，留言反馈"})]})]})]})]}),e.jsxs("div",{className:"faq-section",children:[e.jsx("h2",{children:"常见问题"}),e.jsxs("div",{className:"faq-list",children:[e.jsxs("div",{className:"faq-item",children:[e.jsx("h4",{children:"❓ 如何提交地图纠错？"}),e.jsx("p",{children:'点击"地图纠错"按钮，填写详细的位置信息和问题描述，我们会尽快处理。'})]}),e.jsxs("div",{className:"faq-item",children:[e.jsx("h4",{children:"❓ 产品缺陷会多久修复？"}),e.jsx("p",{children:"我们会根据问题的严重程度和影响范围，优先级高的缺陷会在下个版本修复。"})]}),e.jsxs("div",{className:"faq-item",children:[e.jsx("h4",{children:"❓ 功能建议会被采纳吗？"}),e.jsx("p",{children:"我们重视每一条建议，符合产品方向且需求量大的功能会纳入开发计划。"})]}),e.jsxs("div",{className:"faq-item",children:[e.jsx("h4",{children:"❓ 如何查看反馈处理进度？"}),e.jsx("p",{children:"提交后会收到反馈编号，可通过邮件或联系客服查询处理状态。"})]})]})]}),e.jsxs("div",{className:"feedback-stats",children:[e.jsx("h2",{children:"反馈统计"}),e.jsxs("div",{className:"stats-grid",children:[e.jsxs("div",{className:"stat-card",children:[e.jsx("div",{className:"stat-number",children:"1,234"}),e.jsx("div",{className:"stat-label",children:"总反馈数"})]}),e.jsxs("div",{className:"stat-card",children:[e.jsx("div",{className:"stat-number",children:"856"}),e.jsx("div",{className:"stat-label",children:"已处理"})]}),e.jsxs("div",{className:"stat-card",children:[e.jsx("div",{className:"stat-number",children:"95%"}),e.jsx("div",{className:"stat-label",children:"满意度"})]}),e.jsxs("div",{className:"stat-card",children:[e.jsx("div",{className:"stat-number",children:"24h"}),e.jsx("div",{className:"stat-label",children:"平均响应"})]})]})]})]})}),p=({onBack:t})=>{const i=[{id:1,title:"统一认证参数：key 兼容 ak",description:"对齐高德（key）与百度（ak），统一推荐 key，ak 仅做兼容别名",category:"API设计",votes:112,status:"pending",date:"2026-01-24",impact:"降低多图商接入时的心智成本，减少参数命名混淆带来的接入错误。",technicalDetails:"接口层支持 key 参数；ak 作为别名；文档主推 key；6-12 个月后评估是否废弃 ak；SDK 内部统一 key。",proposedBy:"系统设计组"},{id:2,title:"路径 REST 化 + 版本号",description:"对标高德/百度的 /v3/ 风格，采用 /v1/{resource} 资源化命名",category:"API设计",votes:98,status:"pending",date:"2026-01-24",impact:"支持多版本共存，避免一次性 breaking change，便于灰度与回滚。",technicalDetails:"将 /seg/api/relation/query 迁移到 /v1/districts；旧路径标注 deprecated；提供迁移映射表与灰度策略。",proposedBy:"技术架构组"},{id:3,title:"字段命名规范化（snake_case + 复数列表）",description:"对齐高德 geocodes/pois 复数命名，修正 mediumname/smallname 等无分隔命名",category:"API设计",votes:76,status:"planned",date:"2026-01-24",impact:"提升可读性与类型清晰度，便于多语言 SDK 与文档的一致性。",technicalDetails:"统一 snake_case；示例：medium_name、small_name、result_type；列表字段用复数 districts/streets；输出《API命名规范》。",proposedBy:"开发者体验组"},{id:4,title:"返回结构扁平化",description:"参考高德 status+info+geocodes，去掉 result/query 嵌套，直接返回具名数据列表",category:"API设计",votes:84,status:"planned",date:"2026-01-24",impact:"减少 JSON 解析深度，简化前后端类型定义，降低序列化/反序列化成本。",technicalDetails:"将 data 改为具名复数字段（districts/streets）；移除 result/query；保留 status/info/count 元信息。",proposedBy:"移动开发组"},{id:5,title:"标准状态与错误返回",description:"对齐高德 status+info 与百度 status+message，统一成功/失败语义并提供可读错误文案",category:"API设计",votes:105,status:"in-progress",date:"2026-01-24",impact:"快速定位权限、配额、限流、参数等问题，无需反复联调。",technicalDetails:"status=1 成功/0 失败；info/message 文字说明；预留 error_code 与可重试标识；发布统一错误码表。",proposedBy:"技术服务组"},{id:6,title:"坐标系与精度说明",description:"补充 GCJ-02/WGS-84 等坐标系说明，对齐高德文档的坐标与误差描述",category:"API设计",votes:71,status:"pending",date:"2026-01-24",impact:"避免跨服务坐标偏移问题，减少定位误差带来的业务故障。",technicalDetails:"在响应中声明坐标系；提供坐标转换参数或工具；文档中给出精度/误差范围与样例。",proposedBy:"地图数据组"},{id:7,title:"分页与批量接口设计",description:"补充分页/批量规范，对齐高德的 offset/page_size 方案，避免大结果集一次性返回",category:"API设计",votes:69,status:"planned",date:"2026-01-24",impact:"提升大数据量场景的性能与稳定性，避免超大响应导致超时或内存暴涨。",technicalDetails:"为列表接口增加 limit/offset 或 page/page_size；提供批量调用端点；文档列出返回总量与分页示例。",proposedBy:"后端架构组"},{id:8,title:"参数必填性与组合规则澄清",description:"修复表格“必填”与正文组合规则矛盾的问题，给出可选/必填的清晰矩阵",category:"文档",votes:74,status:"planned",date:"2026-01-24",impact:"减少因参数误解导致的调用失败和无效工单，提升接入成功率。",technicalDetails:"在参数表内直接列出有效组合：为空->全国、省->市、省+市->区、省+市+区->街道；对每个组合给示例与返回预期；移除“全部必填”与正文冲突的描述。",proposedBy:"文档团队"},{id:9,title:"类型与示例一致性校对",description:"确保返回类型表与示例一致，如 data 标注为数组而非 object，并注明空值返回形态",category:"文档",votes:63,status:"planned",date:"2026-01-24",impact:"避免解析错误与类型定义偏差，降低前端/SDK 兼容成本。",technicalDetails:"逐项校对：data/pois/districts 等标为 array<string|object>；注明“无数据返回空数组/空字符串”；补充必需字段的可空性说明。",proposedBy:"QA 文档组"},{id:10,title:"错误码与错误示例覆盖",description:"为每个接口补充失败示例与错误码表，涵盖鉴权/限流/无效参数/无数据/服务异常",category:"API设计",votes:97,status:"in-progress",date:"2026-01-24",impact:"开发者可快速自检并做降级重试，减少支持成本和线上事故。",technicalDetails:"统一错误返回：status=0, info/message=原因, error_code=具体码；示例覆盖：无 key、key 无效、QPS 超限、参数缺失/非法、无数据、内部错误、超时；标注哪些可重试。",proposedBy:"技术支持组"},{id:11,title:"文档导航与可用性修复",description:"修复 404/“无此产品或服务”，提供 API 总览、搜索、Changelog 与新增/下线公告",category:"文档",votes:81,status:"planned",date:"2026-01-24",impact:"新手可快速定位接口，减少迷路与无效链接，提升平台可信度。",technicalDetails:"建立 API 总览页与分类导航；修复失效链接；增加站内搜索；发布变更日志与废弃计划；在控制台/文档显式提示迁移路径。",proposedBy:"平台运营"},{id:12,title:"术语/拼写统一与多语言支持",description:"修正 mediumname/smallname 等拼写；统一术语（key、city_code、type_code）；补充英文版/双语描述",category:"文档",votes:58,status:"planned",date:"2026-01-24",impact:"减少阅读障碍与误解，方便国际化开发者接入。",technicalDetails:"字段重命名或在文档中给出别名；提供英/中对照；在返回中预留英文描述字段（可选）；更新术语表。",proposedBy:"国际化组"},{id:13,title:"调用限制与性能最佳实践",description:"补充 QPS/日配额/超时/重试/幂等等约束与建议，对标高德配额说明",category:"性能与运营",votes:88,status:"planned",date:"2026-01-24",impact:"帮助开发者合理限流与降级，避免突发流量导致的整体不可用。",technicalDetails:"公开各接口 QPS/日额度；建议客户端/服务端超时值；说明重试策略与幂等要求；给出示例：缓存、退避重试、批量/分页优先。",proposedBy:"运维与 SRE"}],n=s=>({pending:"待评估",planned:"已规划","in-progress":"开发中",completed:"已完成"})[s]||s,c=s=>({pending:"#1976d2",planned:"#f57c00","in-progress":"#7b1fa2",completed:"#388e3c"})[s]||"#666";return e.jsxs("div",{className:"feature-improvements-section",children:[e.jsx("button",{className:"back-button",onClick:t,children:"← 返回"}),e.jsxs("div",{className:"section-header",children:[e.jsx("h2",{children:"功能改进"}),e.jsx("p",{className:"section-subtitle",children:"用户建议的新功能和改进"})]}),e.jsx("div",{className:"features-list",children:i.map(s=>e.jsxs("div",{className:"feature-item",children:[e.jsxs("div",{className:"feature-header",children:[e.jsx("h3",{children:s.title}),e.jsx("div",{className:"feature-meta",children:e.jsx("span",{className:"status-badge feature-status",style:{backgroundColor:`${c(s.status)}20`,color:c(s.status)},children:n(s.status)})})]}),e.jsx("p",{className:"feature-description",children:s.description}),s.impact&&e.jsxs("p",{className:"feature-impact",children:["🎯 影响：",s.impact]}),s.technicalDetails&&e.jsxs("div",{className:"feature-tech",children:[e.jsx("div",{className:"tech-label",children:"🛠 实施要点："}),e.jsx("div",{className:"tech-content",children:s.technicalDetails})]}),e.jsxs("div",{className:"feature-footer",children:[e.jsxs("div",{className:"feature-info",children:[e.jsx("span",{className:"category-tag",children:s.category}),e.jsx("span",{className:"date",children:s.date}),s.proposedBy&&e.jsxs("span",{className:"proposed-by",children:["提议：",s.proposedBy]})]}),e.jsxs("div",{className:"votes",children:[e.jsx("span",{className:"vote-icon",children:"👍"}),e.jsx("span",{className:"vote-count",children:s.votes})]})]})]},s.id))})]})},m=({onBack:t})=>{const i=[{id:1,title:"14+个API文档页面链接失效",description:'地理编码、逆地理编码等多个核心API文档返回"无此产品或服务"',detailedDescription:`经测试发现以下API文档页面访问失效：
• /develop/7（地址输入提示）返回404
• /develop/8（地理编码）返回"无此产品"  
• /develop/9（逆地理编码）返回"无此产品"
• /develop/10（地址真实性校验）返回"无此产品"

这导致开发者无法访问完整的API参数说明、返回示例、使用指南。`,type:"文档问题",severity:"high",status:"open",date:"2025-01-24",apiName:"多个API",referenceLinks:[{label:"四级行政区划查询（可访问）",url:"https://lbs.sfmap.com.cn/develop/12"},{label:"地址类型识别（可访问）",url:"https://lbs.sfmap.com.cn/develop/17"}],affectedScenarios:["新开发者入门","接口参数查询","错误排查"],suggestion:"立即恢复所有API文档链接，建立链接检查机制"},{id:2,title:"参数文档与实际逻辑不一致",description:'参数表标记为"必填"，但接口说明又允许参数可选',detailedDescription:`参数表显示province、city、county都是必填
但接口说明中写道：
"如果参数都不传，返回所有省"
"只传province，返回该省下所有市"

这自相矛盾：如果是必填，怎么能都不传？
缺少参数组合规则说明。`,type:"文档问题",severity:"high",status:"open",date:"2025-01-24",apiName:"四级行政区划查询",referenceLinks:[{label:"问题页面",url:"https://lbs.sfmap.com.cn/develop/12"}],affectedScenarios:["参数验证","请求失败排查","开发者困惑"],suggestion:"添加参数组合规则章节，明确哪些参数是可选的"},{id:3,title:"返回参数类型说明与示例不符",description:"返回参数表显示data字段类型为object，但示例中data是数组",detailedDescription:`返回参数表：
| data | 响应数据集 | object |

返回示例：
{
  "result": {
    "data": [
      "南头街道",
      "南山街道"
    ]
  }
}

明显矛盾：表格说data是object，示例显示data是string[]`,type:"文档问题",severity:"high",status:"open",date:"2025-01-24",apiName:"四级行政区划查询",referenceLinks:[{label:"返回参数表",url:"https://lbs.sfmap.com.cn/develop/12#返回参数"}],affectedScenarios:["数据解析","类型定义","前端集成"],suggestion:"更正返回参数表：data应标记为array<string>类型"},{id:4,title:"缺少完整的错误码说明表",description:"缺少status=1时的错误返回示例和错误信息字段说明",detailedDescription:`当前所有API文档只展示成功场景（status=0）
缺少以下错误场景：
1. 无效参数错误 - 返回什么？
2. 权限错误 - 如何区分？
3. 限流错误 - HTTP状态码和返回体是什么？
4. 无数据场景 - 返回空数组还是错误？
5. 服务内部错误 - 如何区分是否可重试？
6. 超时场景 - 客户端如何检测？

导致开发者无法进行完整的错误处理。`,type:"文档问题",severity:"high",status:"open",date:"2025-01-24",apiName:"全部API",referenceLinks:[{label:"HTTP状态码规范",url:"https://httpwg.org/specs/rfc7231.html#status.codes"}],affectedScenarios:["错误处理","故障排查","用户反馈"],suggestion:"发布API错误码完整参考文档，列出所有可能的失败状态"},{id:5,title:"地址类型识别API参数说明模糊",description:"opt参数说明不清，缺少参数值为poi时的说明",detailedDescription:`opt参数文档说明：
"参数为空，输出poi+aoi混合类型 参数为aoi，输出aoi类型"

问题：
1. 语句不清楚，应该用表格
2. 缺少opt="poi"的说明
3. 缺少参数示例和默认行为
4. 没有说明参数大小写敏感性
5. 无效参数值时的处理`,type:"文档问题",severity:"medium",status:"open",date:"2025-01-24",apiName:"地址类型识别",referenceLinks:[{label:"问题API文档",url:"https://lbs.sfmap.com.cn/develop/17"}],affectedScenarios:["参数组合","请求失败","功能实现"],suggestion:"使用表格重新组织参数说明，列出所有参数取值及对应行为"},{id:6,title:"缺少数据字段值的对照表",description:"typecode字段值没有对应的编码说明",detailedDescription:`返回示例：
{
  "typecode": "190403",
  "mediumname": "门牌信息",
  "smallname": "楼栋号"
}

问题：
1. typecode "190403"代表什么？
2. 如何解析？每位数字的含义？
3. 缺少typecode对照表
4. mediumname和smallname的层级关系不清
5. 是否所有地址都能被准确分类？

导致开发者需要逐个测试才能理解数据含义。`,type:"文档问题",severity:"high",status:"open",date:"2025-01-24",apiName:"地址类型识别",referenceLinks:[{label:"返回参数说明",url:"https://lbs.sfmap.com.cn/develop/17#返回参数"}],affectedScenarios:["数据分类","业务逻辑","结果展示"],suggestion:"发布地址类型编码对照表和类型层级关系文档"},{id:7,title:"缺少API调用限制说明",description:"无QPS限制、日均额度限制、单次请求大小限制说明",detailedDescription:`开发者需要了解但文档完全缺失：

1. 请求频率限制
   - 单账户QPS是多少？
   - 是否有突发流量处理？

2. 日均/月均额度
   - 免费层日均调用次数？
   - 商用版有无限制？

3. 单次请求限制
   - 最大POST body大小？
   - 最多支持多少条地址批量？

4. 超时设置
   - 服务端响应超时时间？
   - 是否支持请求级别超时？

5. 并发限制
   - 单用户最大并发连接数？
   - 单IP限制？

缺乏这些信息导致无法评估成本、架构设计无法优化。`,type:"文档问题",severity:"high",status:"open",date:"2025-01-24",apiName:"全部API",referenceLinks:[{label:"高德配额说明",url:"https://lbs.amap.com/api/webservice/geopositioning/"}],affectedScenarios:["架构设计","成本评估","容量规划"],suggestion:"发布API调用限制与配额说明文档"},{id:8,title:"缺少坐标系说明",description:"地理编码API应说明返回坐标使用的坐标系",detailedDescription:`坐标系问题的重要性：

1. 不同坐标系精度差异很大
   - WGS-84（全球标准）
   - GCJ-02（中国火星坐标）
   - 同一个点的经纬度可能相差几百米

2. 错误的坐标系使用导致
   - 地点定位偏差
   - 路线规划错误
   - 与其他地图服务不兼容

应该说明：
- 返回坐标系标准
- 是否支持坐标系转换
- 与地图展示组件的匹配关系`,type:"文档问题",severity:"medium",status:"open",date:"2025-01-24",apiName:"地理编码",referenceLinks:[{label:"高德坐标系说明",url:"https://lbs.amap.com/api/webservice/geopositioning"}],affectedScenarios:["地点定位","地图展示","跨系统集成"],suggestion:"补充坐标系与精度说明章节"},{id:9,title:"缺少批量处理接口或说明",description:"大批量数据需要循环调用单条接口",detailedDescription:`实际业务场景：
- 地址校验：一次需要处理10,000+条地址
- 企业查询：日均查询100万级企业信息
- 地理编码：需要给100万商户进行坐标转换

当前问题：
1. 没有批量API
   - 必须循环单条请求
   - 1000条地址需要1000次请求
   - 网络往返延迟×1000

2. 性能无法优化
   - 无缓存建议
   - 无并发调用指南

3. 成本无法评估
   - 如果有最小批量量？
   - 批量与单条的价格是否不同？`,type:"文档问题",severity:"medium",status:"open",date:"2025-01-24",apiName:"地址相关API",affectedScenarios:["大数据处理","导入导出","定期同步"],suggestion:"补充批量处理指南，或提供服务端批处理API"},{id:10,title:"缺少最佳实践和常见错误指南",description:"缺少最佳实践指南、常见错误排查、性能优化建议",detailedDescription:`新开发者面临的问题：
- 参数怎样设置性能最优？
- 返回的数据如何缓存？
- 如何处理高并发场景？
- 请求失败应该重试吗？
- 如何监控API性能？

常见错误处理：
- 不知道某些参数会显著影响响应时间
- 错误的字段类型导致数据解析失败
- 没有错误重试机制
- 同步阻塞等待所有请求
- 没有超时保护

应该包含的内容：
1. 参数优化建议
2. 错误处理方案
3. 并发处理指南
4. 性能监控方法`,type:"文档问题",severity:"medium",status:"open",date:"2025-01-24",apiName:"全部API",referenceLinks:[{label:"Google API最佳实践",url:"https://cloud.google.com/docs/authentication/best-practices"}],affectedScenarios:["生产环境","性能优化","故障排查"],suggestion:"发布API最佳实践指南，包含常见错误案例和解决方案"},{id:11,title:"缺少多编程语言代码示例",description:"所有示例仅提供JSON格式，缺少主流语言实现",detailedDescription:`当前文档代码示例问题：

1. 仅有JSON示例
   - 无法直接复制使用
   - 开发者需要自己实现HTTP请求逻辑
   - 容易出现编码、超时、异常处理错误

2. 缺少主流语言示例
   - Python（数据分析最常用）
   - Java（企业应用标准）
   - JavaScript/Node.js（前端集成）
   - Go（性能型应用）
   - C#/.NET（Windows应用）

3. 缺少SDK
   - 是否有官方SDK？
   - 是否支持流行的HTTP库？

开发者成本：
- 集成时间增加2-3倍
- 测试覆盖不完整
- 容易引入安全问题`,type:"文档问题",severity:"medium",status:"open",date:"2025-01-24",apiName:"全部API",affectedScenarios:["快速集成","开发效率","错误降低"],suggestion:"提供Python、Java、JavaScript等主流语言的完整代码示例"},{id:12,title:"缺少参数可选组合的说明",description:"某些API的参数在不同情况下的必填性不同",detailedDescription:`参数组合问题（以四级行政区划查询为例）：

场景1：查询全国所有省
不传任何地区参数
→ 返回所有省

场景2：查询广东省下的市
只传province=广东省
→ 返回该省下所有市

场景3：查询深圳市下的区
传province+city
→ 返回该市下所有区

场景4：查询南山区下的街道
传province+city+county
→ 返回该区下所有街道

场景5：有效但文档未说明
- 可以只传city吗？
- 可以只传county吗？
- province+county（跳过city）可以吗？

缺乏清晰的参数组合规则导致：
- 开发者尝试测试失败的组合
- 无法准确构建查询逻辑`,type:"文档问题",severity:"medium",status:"open",date:"2025-01-24",apiName:"四级行政区划查询等",referenceLinks:[{label:"参数组合规则",url:"https://lbs.sfmap.com.cn/develop/12"}],affectedScenarios:["参数设计","场景探索","集成测试"],suggestion:"添加参数组合规则表，列出所有有效的参数组合"},{id:13,title:"缺少数据准确性说明",description:"文档声称精准度99.81%，但无详细定义和测试范围",detailedDescription:`丰图官网宣称的数据指标：
"语义准确度达99.81%"
"地址解析准确率100%"

但这些数据的真实含义不清：

1. 精准度的定义
   - 是字符级匹配准确率？
   - 还是地理位置准确度？
   - 误差范围多少？

2. 测试的数据范围
   - 测试了多少条地址？
   - 覆盖了全国所有地区吗？
   - 包括偏远农村地区吗？

3. 不同地区的准确度
   - 城市与农村的准确度差异？
   - 数据多久更新一次？
   - 新地址何时能被识别？

对开发者的影响：
- 无法判断API是否适合自己的业务
- 无法评估需要多少人工核验`,type:"文档问题",severity:"medium",status:"open",date:"2025-01-24",apiName:"地址输入提示",referenceLinks:[{label:"官网数据声称",url:"https://lbs.sfmap.com.cn/"}],affectedScenarios:["质量评估","选型决策","SLA设定"],suggestion:"补充数据准确度说明文档，明确定义、测试方法、地区差异"},{id:14,title:"缺少API响应时间SLA说明",description:"无平均响应时间、P99响应时间等性能指标",detailedDescription:`生产环境中需要了解的性能指标：

1. 响应时间
   - P50响应时间（中位数）？
   - P95响应时间（95%分位数）？
   - P99响应时间（99%分位数）？

2. 超时配置
   - 推荐的请求超时时间？
   - 服务端会在多久后强制断开？

3. 可用性
   - 服务可用性SLA是多少？
   - 是否有服务级别保证？

4. 性能规律
   - 不同时段的性能差异？
   - 并发请求下的响应时间？

实际应用影响：
- 无法设置合理的超时时间
- 无法承诺给客户的响应时间
- 无法设计降级方案`,type:"文档问题",severity:"medium",status:"open",date:"2025-01-24",apiName:"全部API",referenceLinks:[{label:"AWS SLA声明",url:"https://aws.amazon.com/cn/about-aws/global-infrastructure/regional-product-services/"}],affectedScenarios:["性能评估","SLA承诺","超时配置"],suggestion:"发布性能指标说明文档，包含响应时间基准和SLA"},{id:15,title:"缺少字段排序规则说明",description:"返回数据集中的数据顺序规则不清楚",detailedDescription:`在四级行政区划查询返回的街道列表中：
"南头街道", "南山街道", "沙河街道", ...

问题：
1. 这个顺序是按什么排序的？
   - 按行政区划代码？
   - 按名称拼音？
   - 按面积大小？

2. 排序是否稳定？
   - 每次请求返回的顺序相同吗？
   - 如果数据更新，顺序会变吗？

3. 分页问题
   - 数据量大时如何分页？
   - 是否支持limit/offset？

实际影响：
- 前端展示时不知道如何排序
- 用户体验差`,type:"文档问题",severity:"low",status:"open",date:"2025-01-24",apiName:"四级行政区划查询",referenceLinks:[{label:"返回示例",url:"https://lbs.sfmap.com.cn/develop/12#返回示例"}],affectedScenarios:["数据展示","用户体验","排序逻辑"],suggestion:"补充排序规则说明，如支持排序参数则详细说明"},{id:16,title:"缺少数据更新频率说明",description:"地址数据的更新频率不明确",detailedDescription:`对数据及时性有影响的关键问题：

1. 数据更新频率
   - 行政区划数据多久更新一次？
   - 企业信息数据多久更新一次？
   - 地名地址数据多久更新一次？

2. 新增数据的可见性
   - 新成立的企业多久能被查询到？
   - 新开楼盘多久能被地理编码？
   - 地址变更多久能被识别？

3. 数据一致性
   - 多个数据源之间是否一致？
   - 行政区划变更时如何同步？

4. 历史数据
   - 是否支持查询历史版本的数据？
   - 是否能追溯数据的修改记录？

实际应用影响：
- 实时数据应用无法准确承诺
- 数据导入导出的合理性无法评估
- 周期性更新的时机无法确定`,type:"文档问题",severity:"medium",status:"open",date:"2025-01-24",apiName:"全部地址API",affectedScenarios:["数据同步","实时性保证","周期规划"],suggestion:"补充数据更新政策说明，明确各类数据的更新频率"},{id:17,title:"缺少地域覆盖范围说明",description:"各API的数据覆盖范围不清楚",detailedDescription:`不同API的数据覆盖范围可能不同，但文档未说明：

1. 地理范围
   - 仅覆盖中国还是全球？
   - 中国境内是否全覆盖？
   - 香港、澳门、台湾是否包含？

2. 数据覆盖度
   - 城市覆盖率多少？
   - 县城、乡镇的覆盖率？
   - 偏远村庄是否覆盖？

3. 地址类型覆盖
   - 所有类型地址都支持吗？
   - 门牌号、楼栋号、室号覆盖度？
   - 虚拟地址、临时地址？

4. 与地图、定位的关系
   - 地址库与地图展示区域是否一致？
   - 定位API的覆盖范围？
   - 室内定位的覆盖建筑物？

无法准确评估产品适用范围`,type:"文档问题",severity:"medium",status:"open",date:"2025-01-24",apiName:"全部API",referenceLinks:[{label:"覆盖范围说明",url:"https://lbs.sfmap.com.cn/"}],affectedScenarios:["产品适用范围","业务扩展","质量评估"],suggestion:"发布数据覆盖范围说明文档，包含地理范围地图"},{id:18,title:"缺少废弃API的迁移指南",description:"若某个API版本被弃用，应提供迁移指南",detailedDescription:`在API演进过程中，旧版本可能被标记为废弃。

应该清楚说明：

1. 弃用周期
   - 何时开始停止维护？
   - 何时完全下线？
   - 具体时间表是什么？

2. 迁移指南
   - 推荐的替代API是什么？
   - 新旧API的功能对比？
   - 参数如何映射？
   - 返回数据如何转换？

3. 迁移工具
   - 是否提供自动转换脚本？
   - 是否提供迁移检查工具？

4. 支持期限
   - 旧版本API的支持截止日期？
   - 截止后是否直接返回错误？

缺乏迁移指导导致：
- 开发者可能使用已废弃的API
- 突然下线导致服务故障`,type:"文档问题",severity:"low",status:"open",date:"2025-01-24",apiName:"全部API",referenceLinks:[{label:"Google API弃用政策",url:"https://cloud.google.com/apis/design/versioning"}],affectedScenarios:["长期维护","版本升级","成本管理"],suggestion:"建立API生命周期管理政策"},{id:19,title:"文档导航和索引不完整",description:"缺少API总览页、功能分类导航",detailedDescription:`当前文档的导航问题：

1. 缺少统一入口
   - 无API总览页
   - 无完整的API列表
   - 无功能分类导航
   - 搜索功能不便捷

2. 查找困难
   - 有多少个API？
   - 它们分别用来做什么？
   - 按功能分类是怎样的？
   - 推荐的使用流程？

3. 链接管理
   - API编号规律？
   - 如何发现新增API？
   - 旧API与新API的关系？

用户体验差的表现：
- 新用户不知道从哪里开始
- 无法快速定位需要的API
- 文档间的跳转不顺畅
- 无法发现相关的补充API`,type:"文档问题",severity:"medium",status:"open",date:"2025-01-24",apiName:"全部",referenceLinks:[{label:"高德API导航",url:"https://lbs.amap.com/api/webservice/guide/api/georegeo"}],affectedScenarios:["开发者入门","功能探索","产品发现"],suggestion:"重新设计API文档导航，提供按功能分类的总览"},{id:20,title:"返回数据示例不包含错误场景",description:"所有文档示例都仅展示成功场景",detailedDescription:`当前文档的问题：

1. 仅有成功示例
   - 返回status=0的示例
   - 缺少status=1的示例
   - 缺少各种错误场景的返回

2. 常见错误场景缺失
   - 无效参数错误
   - 权限错误
   - 限流错误
   - 无数据场景
   - 服务内部错误
   - 超时场景

3. 错误字段不清楚
   - 错误信息在哪个字段？
   - 是否有错误码字段？
   - 嵌套结构如何？

4. 多语言错误
   - 错误信息是中文还是英文？
   - 是否支持多语言？

5. 开发者体验
   - 需要依赖实际调用才能知道错误
   - 容易遗漏某些错误处理
   - 自动化测试困难`,type:"文档问题",severity:"medium",status:"open",date:"2025-01-24",apiName:"全部API",referenceLinks:[{label:"HTTP状态码规范",url:"https://httpwg.org/specs/rfc7231.html#status.codes"}],affectedScenarios:["错误处理","用户体验","故障诊断"],suggestion:"在每个API文档补充错误场景部分，提供完整的返回示例"}],n=s=>({high:"严重",medium:"中等",low:"轻微"})[s]||s,c=s=>({open:"待处理","in-progress":"处理中",resolved:"已解决"})[s]||s;return e.jsxs("div",{className:"bug-reports-section",children:[e.jsx("button",{className:"back-button",onClick:t,children:"← 返回"}),e.jsxs("div",{className:"section-header",children:[e.jsx("h2",{children:"产品缺陷"}),e.jsx("p",{className:"section-subtitle",children:"丰图开放平台 API 文档问题分析（20项）"})]}),e.jsx("div",{className:"bugs-list",children:i.map(s=>e.jsxs("div",{className:"bug-item",children:[e.jsxs("div",{className:"bug-header",children:[e.jsx("h3",{children:s.title}),e.jsxs("div",{className:"bug-badges",children:[e.jsx("span",{className:"type-badge",children:s.type}),e.jsx("span",{className:`severity-badge ${s.severity}`,children:n(s.severity)}),e.jsx("span",{className:`status-badge ${s.status}`,children:c(s.status)})]})]}),e.jsx("p",{className:"bug-description",children:s.description}),s.detailedDescription&&e.jsxs("div",{className:"bug-detailed-description",children:[e.jsx("p",{className:"detailed-label",children:"📝 详细说明："}),e.jsx("p",{className:"detailed-text",children:s.detailedDescription})]}),e.jsx("div",{className:"bug-meta",children:s.apiName&&e.jsxs("span",{className:"api-name",children:["📌 涉及API：",s.apiName]})}),s.affectedScenarios&&s.affectedScenarios.length>0&&e.jsxs("div",{className:"affected-scenarios",children:[e.jsx("span",{className:"scenarios-label",children:"⚠️ 影响场景："}),e.jsx("div",{className:"scenarios-list",children:s.affectedScenarios.map((a,l)=>e.jsx("span",{className:"scenario-tag",children:a},l))})]}),s.referenceLinks&&s.referenceLinks.length>0&&e.jsxs("div",{className:"reference-links",children:[e.jsx("span",{className:"links-label",children:"🔗 参考链接："}),e.jsx("div",{className:"links-list",children:s.referenceLinks.map((a,l)=>e.jsxs("a",{href:a.url,target:"_blank",rel:"noopener noreferrer",className:"reference-link",children:[a.label," →"]},l))})]}),s.suggestion&&e.jsxs("div",{className:"suggestion-box",children:[e.jsx("p",{className:"suggestion-label",children:"💡 改进建议："}),e.jsx("p",{className:"suggestion-text",children:s.suggestion})]}),e.jsx("div",{className:"bug-footer",children:e.jsx("span",{className:"bug-date",children:s.date})})]},s.id))})]})},v=()=>{const[t,i]=d.useState("overview"),n=r(),c=s=>{s==="map-corrections"?n("/map-correction"):i(s)};return e.jsxs("div",{className:"improvement-page",children:[t==="overview"&&e.jsx(o,{onNavigate:c}),t==="bugs"&&e.jsx(m,{onBack:()=>i("overview")}),t==="features"&&e.jsx(p,{onBack:()=>i("overview")}),t==="map-corrections"&&e.jsxs("div",{className:"improvement-section",children:[e.jsx("button",{className:"back-button",onClick:()=>i("overview"),children:"← 返回"}),e.jsx("h2",{children:"地图纠错"}),e.jsx("p",{className:"coming-soon",children:"即将上线..."})]})]})};export{v as default};
